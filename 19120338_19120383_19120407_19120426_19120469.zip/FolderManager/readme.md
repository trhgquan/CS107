# Project 1 - Hệ thống tập tin
- Trường hợp gặp lỗi đọc ra CreateFile: 5 => Mở Visual Studio bằng quyền admin.
- Trường hợp gặp lỗi ReadFile: 87 => Số lượng byte đọc khi dùng ReadFile phải có dạng 512*i (i > 0)
