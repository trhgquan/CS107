#pragma once
#ifndef _NTFS_BIOS_PARAMETER_BLOCK_H_
#define _NTFS_BIOS_PARAMETER_BLOCK_H_

#include "BIOSParameterBlock.h"

typedef BIOSParameterBlock NTFS_BIOSParameterBlock;

#endif // !_NTFS_BIOS_PARAMETER_BLOCK_H_
